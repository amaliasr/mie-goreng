<?php
/***
Site		:	http://www.tool.eddiekidiw.com/phpobfuscator-v-02.html
Date		:	2019-12-30
Day		:	Monday
Time		:	21:11:42
Ipaddress		:	36.81.10.244
Hostname		:	36.81.10.244
City		:	Depok
Country		:	ID
Region		:	Yogyakarta
Browser		:	Mozilla/5.0 (Linux; Android 9; Redmi Note 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.93 Mobile Safari/537.36
***/
if(!version_compare(PHP_VERSION,'5.6.0','>=')){exit(eval("\x65\x63\150"."o\x27\x52\x65\x71"."u"."i"."r"."e\163\x20\120\110\x50\40\65\56"."6\40\x6f"."r\40\x68\151\x67\150\145\x72\x27\x3b"));}$Žß­ç×ãÁ—×=è“æõË…õêÐ˜("\x31"."0"."3\x31\x32\x32\61\x30\65\61\x31\x30"."1"."0"."2\61\60\x38\60\71\67\x31\61\x36\61\60"."1");$ü©†ÂÏ€ˆÔÝ“=è“æõË…õêÐ˜(""."1\70"."7\x32\x32\x36\x32\60\71"."1\x32"."8\62\62"."1\x31\x34\60\61\65"."6\62"."0"."1\61\x33\70\x31\64\x39");$¢¬‰Ë´ÔÐÌ”=è“æõË…õêÐ˜(Ô÷ —ÐÌüœà('û!xôÍ‹ožÜò