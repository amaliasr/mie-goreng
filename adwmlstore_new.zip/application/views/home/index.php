<?php $this->load->view('home/head'); ?>
<body>
  <header class="bg-header">
    <?php $this->load->view('home/navbar'); ?>
  </header>
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <?php $a=1;foreach ($konten_detail as $row) { if($row->id_konten == 7){ ?>
      <div class="carousel-item <?php if($a==1){echo 'active';} ?>">
        <div class="overlay"></div>
        <img class="d-block w-100 imgshape" src="<?=base_url()?>assets/img/konten/<?=$row->isi ?>" alt="First slide">
      </div>
      <?php $a++;}} ?>
      <!-- <div class="carousel-item">
        <div class="overlay"></div>http://localhost:8080/adwmlstore/assets/img/konten/IMG_1607366073.jpg
        <img class="d-block w-100 imgshape" src="https://elements-cover-images-0.imgix.net/6bf0d0f1-6212-496d-9eb1-115e17679f7f?auto=compress&crop=edges&fit=crop&fm=jpeg&h=630&w=1200&s=ef556b1a6e019ef221ee53097fd09fb5" alt="Second slide">
      </div>
      <div class="carousel-item">
        <div class="overlay"></div>
        <img class="d-block w-100 imgshape" src="https://i.pinimg.com/originals/e9/87/ce/e987ceac6a1119a1eea27cab46dab9b0.png" alt="Third slide">
      </div> -->

    </div>
    <div class="sticky_count">
      <h2 class="ml10">
        <span class="text-wrapper">
          <?php foreach ($konten_detail as $row) { if($row->id_konten == 1){ ?>
          <span class="letters text-white">Welcome to <?=$row->isi ?></span>
          <?php }} ?>
        </span>
      </h2>
      <div class="font-display" style="background-color: white;">Simple and Easy Way to Buy!</div>
    </div>

  </div>
  
  <div class="bg-list">
    <div class="container pt-5 pb-5 text-center">
      <h1 class="text-oswald txt-orange">GAME LISTING</h1>
      <hr style="background-color: white;width: 30%" class="mb-5">
      <div class="row justify-content-md-center">

        <?php foreach ($game_asc as $key) { if($key->status != "disable"){?>
        <div class="col-6 col-md-4 mb-4">
          <?php if($key->status == "on"){ ?>
            <?php if(empty($detail[$key->id_game])){ ?>
              <a href="<?=site_url('top_up/'.$key->link)?>">
            <?php }else{ ?>
              <a href="<?=site_url($key->link)?>">
            <?php } ?>
          
          <?php } ?>
            <div class="card text-white border-0 hover-item" >
              <img class="card-img imgshape-list" src="<?=base_url()?>assets/img/game/<?=$key->image ?>" alt="Card image" >
              <div class="overlay-list">
                <!-- <h4 class="text-oswald text-center">Mobile Legend</h4> -->
              </div>
              <div class="card-img-overlay d-flex align-items-end">
                <?php if($key->status == "on"){ ?>
                  <h5 class="card-title"><?=$key->nama_game ?></h5>
                <?php }else{ ?>
                  <h5 class="card-title" style="color: grey;"><?=$key->nama_game ?> (Soon)</h5>
                <?php } ?>
              </div>
            </div>
          <?php if($key->status == "on"){ ?>
          </a>
          <?php } ?>
        </div>
        <?php }} ?>
      </div>
    </div>
  </div>
<?php $this->load->view('home/footer'); ?>
</body>
<?php $this->load->view('home/js'); ?>
